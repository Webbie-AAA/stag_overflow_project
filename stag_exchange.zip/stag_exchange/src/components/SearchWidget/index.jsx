import React, { useState, useEffect } from "react"
import { SearchForm } from "../"
import SearchFilters from "../SearchFilters"
import { useAPI } from "../../contexts/contexts"

export default function SearchWidget() {

    const { setData } = useAPI()
    const [searchString, setSearchString] = useState("Deer")
    const [startDate, setStartDate] = useState("")
    const [endDate, setEndDate] = useState("")

    useEffect(() => {

        async function fetchData() {
            try{
                const params = new URLSearchParams({
                    taxon_name: searchString,
                    start_date: startDate,
                    end_date: endDate,
                    order: "desc",
                })

                const response = await fetch(`https://api.inaturalist.org/v2/observations?${params}`)

                if (!response.ok) {
                    throw new Error("Failed to fetch sightings")
                }

                const rawData = await response.json()
                setData(rawData.results)
            } catch (error) {
                console.error("Error fetching data:", error)
            }
        }
        fetchData()
    }, [searchString, startDate, endDate, setData])

    return (
        <div>
            <SearchForm handleSearch={setSearchString} lastSearch={searchString} />
            <SearchFilters 
                startDate={startDate}
                endDate={endDate}
                setStartDate={setStartDate}
                setEndDate={setEndDate}
            />
        </div>
    )
}
