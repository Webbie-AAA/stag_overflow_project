import React, { useState, useEffect } from "react"
import { SearchForm } from "../"
import { useAPI } from "../../contexts/contexts"

export default function SearchWidget() {

    const { setData } = useAPI()
    const [searchString, setSearchString] = useState("Deer")

    useEffect(() => {

        async function fetchData() {
            const response = await data.search(searchString)
            const rawData = await response.json()
            const data = rawData.map(search => ({
                id: search.id,
                name: search.name,
                description: search.description
            }))
        }

        fetchData()
    }, [searchString, data])

    return (
        <div>
            <SearchForm handleSearch={setSearchString} lastSearch={searchString} />
        </div>
    )
}
