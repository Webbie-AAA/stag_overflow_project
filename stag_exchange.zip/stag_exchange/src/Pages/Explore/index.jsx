import React from "react";
import SightingGallery from "../../components/SightingGallery";
import SearchWidget from "../../components/SearchWidget";
import SightingCard from "../../components/SightingCard";
import { useAPI } from "../../contexts/contexts";

export default function Explore() {
  const {data} = useAPI()
  return (
    <div>
      <SearchWidget />

      <SightingGallery />

      <h1>Sightings: {data.length}</h1>

      <div className="sightings-grid">
        {data.map((sighting) => (
          <SightingCard key={sighting.id} observation={sighting} />
        ))}
      </div>
    </div>
  );
}
