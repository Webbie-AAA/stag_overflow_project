export {default as Browse} from './Browse'
export {default as Home} from './Home'
export {default as Favourites} from './Favourites'
export {default as Explore} from './Explore';