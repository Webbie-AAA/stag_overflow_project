import React from 'react'
import { useAPI } from '../../contexts/contexts'
import SearchWidget from '../../components/SearchWidget'

export default function Home() {
  const {data} = useAPI()
  return (
    <>
      <SearchWidget />
      <h1>Sightings: {data.length}</h1>
      <pre>{JSON.stringify(data[0], null, 2)}</pre>
    </>
  )
}
